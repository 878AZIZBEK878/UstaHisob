USTAHISOB ANDROID LOYIHASI

Bu Android Studio uchun WebView ilova loyihasi. Hozircha APK emas.

APK build qilish:
1. Kompyuterga Android Studio o‘rnating.
2. Ushbu loyihani Android Studio'da Open orqali oching.
3. Gradle sync tugashini kuting.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK app/build/outputs/apk/debug/app-debug.apk ichida hosil bo‘ladi.

Yangilash:
- MainActivity.java ichidagi UPDATE_JSON manzilini o‘zingizning HTTPS hosting manzilingizga almashtiring.
- Har yangi versiyada app/build.gradle ichidagi versionCode ni oshiring.
- APKni o‘sha applicationId va aynan bir xil signing key bilan imzolang.
- update.json faylida versionCode va apkUrl ni yangi APK manziliga qo‘ying.
- Telefon yangilanishni ko‘rsatadi. Android xavfsizlik sababli foydalanuvchi o‘rnatishni tasdiqlaydi.

MUHIM:
- Bu muhitda Android SDK/Gradle build muhiti yo‘qligi sababli APKni hozir kompilyatsiya qilib bo‘lmadi.
- Avtomatik yangilash ishlashi uchun doimiy HTTPS hosting kerak. UPDATE_JSON hozir ataylab placeholder.
- Ma’lumotlar WebView localStorage xotirasida saqlanadi. Bir xil package ID va imzo bilan yangilansa, odatda ilova ma’lumotlari saqlanadi. Ilovani o‘chirib qayta o‘rnatish ma’lumotlarni yo‘qotishi mumkin; zaxira nusxa oling.
