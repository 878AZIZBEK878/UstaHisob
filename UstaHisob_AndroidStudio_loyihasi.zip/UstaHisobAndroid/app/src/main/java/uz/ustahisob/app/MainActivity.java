package uz.ustahisob.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.*;
import java.net.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    // Publish update.json and the APK at these HTTPS addresses when releasing a new version.
    private static final String UPDATE_JSON = "https://YOUR-DOMAIN.example/ustahisob/update.json";
    private static final int CURRENT_VERSION = 1;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");
        checkForUpdate();
    }

    private void checkForUpdate() {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection)new URL(UPDATE_JSON).openConnection();
                c.setConnectTimeout(5000); c.setReadTimeout(5000);
                c.connect();
                if (c.getResponseCode() != 200) return;
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder b = new StringBuilder(); String line;
                while ((line = r.readLine()) != null) b.append(line);
                r.close(); c.disconnect();
                JSONObject j = new JSONObject(b.toString());
                int version = j.getInt("versionCode");
                String apk = j.getString("apkUrl");
                String notes = j.optString("notes", "Yangi imkoniyatlar va yaxshilanishlar");
                if (version > CURRENT_VERSION) runOnUiThread(() -> showUpdate(apk, notes));
            } catch (Exception ignored) { }
        }).start();
    }

    private void showUpdate(String apkUrl, String notes) {
        new AlertDialog.Builder(this)
            .setTitle("UstaHisob yangilanishi")
            .setMessage("Yangi versiya mavjud.\n" + notes + "\n\nYangilaysizmi? Ma’lumotlar ilova xotirasida saqlanadi.")
            .setNegativeButton("Keyinroq", (d,w) -> {})
            .setPositiveButton("Yangilash", (d,w) -> downloadUpdate(apkUrl))
            .show();
    }

    private void downloadUpdate(String url) {
        try {
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setTitle("UstaHisob yangilanishi");
            req.setDescription("APK yuklanmoqda");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "ustahisob-update.apk");
            DownloadManager dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
            long id = dm.enqueue(req);
            registerReceiver(new BroadcastReceiver() {
                @Override public void onReceive(Context context, Intent intent) {
                    if (intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) != id) return;
                    try {
                        File f = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "ustahisob-update.apk");
                        Uri uri = FileProvider.getUriForFile(MainActivity.this, "uz.ustahisob.app.fileprovider", f);
                        if (android.os.Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                            Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
                            startActivity(settings);
                            Toast.makeText(MainActivity.this, "UstaHisob uchun APK o‘rnatishga ruxsat bering, so‘ng yuklangan faylni oching.", Toast.LENGTH_LONG).show();
                            return;
                        }
                        Intent install = new Intent(Intent.ACTION_VIEW);
                        install.setDataAndType(uri, "application/vnd.android.package-archive");
                        install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(install);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Yangilashni ochib bo‘lmadi: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), Context.RECEIVER_NOT_EXPORTED);
            Toast.makeText(this, "Yangilanish yuklanmoqda", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Yuklab olishda xatolik", Toast.LENGTH_SHORT).show();
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
